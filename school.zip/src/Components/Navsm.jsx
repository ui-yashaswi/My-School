import React from "react";

function NavSecondery() {
  return <div></div>;
}

export default NavSecondery;
