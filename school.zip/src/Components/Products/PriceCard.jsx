import React from "react";

function PriceCard() {
  return <div>PriceCard</div>;
}

export default PriceCard;
