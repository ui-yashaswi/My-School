import axios from "axios";

export const api = axios.create({
  baseURL: "https://myschool-backend-node.onrender.com",
});
